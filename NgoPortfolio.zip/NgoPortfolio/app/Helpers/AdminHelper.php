<?php

namespace App\Helpers;


class AdminHelper
{
    public static function middleware($class)
    {
        $class->middleware('preventBackHistory');
        $class->middleware('auth:admin');
    }

}