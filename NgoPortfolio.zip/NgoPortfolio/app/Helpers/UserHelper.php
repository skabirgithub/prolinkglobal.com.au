<?php

namespace App\Helpers;


class UserHelper
{

    public static function middleware($class){
        $class->middleware('preventBackHistory');
        $class->middleware('auth');
        //middleware for status check
        // $class->middleware('checkStatus');
        //middleware for email verification
    //    $class->middleware('verified');

    }

}