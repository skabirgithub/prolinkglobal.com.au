<?php

namespace App\Helpers;


class FrontendHelper
{
}
