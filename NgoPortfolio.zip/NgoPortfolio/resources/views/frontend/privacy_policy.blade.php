@extends('layouts.frontend')
@section('title') Privacy Policy Shataphool Bangladesh @endsection
@section('content')
@include('includes.banner',['programName'=>'Privacy Policy'])
<!-- WHO WE ARE -->
<section class="padding-top-70 padding-bottom-70">
    <div class="container">
        <div class="who-we">
            <div class="row">
                <div class="col-md-6">
                    <h3 class="font-normal">Shataphool Bangladesh: Privacy Policy</h3>
                    <h6>Privacy Policy</h6>
                    <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis beatae, explicabo quidem officiis dolor natus nostrum tempora nesciunt cupiditate unde suscipit harum! Explicabo nobis similique ipsa temporibus molestias quidem omnis.
                    </p>

                </div>
            </div>
        </div>


    </div>
</section>
@endsection
